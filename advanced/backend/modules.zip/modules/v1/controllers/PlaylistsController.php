<?php

namespace backend\modules\v1\controllers;
use yii\rest\ActiveController;
use yii\web\Request;
use Yii;

class PlaylistsController extends ActiveController
{
	public $modelClass = 'common\models\Playlists';
    public $modelPHM = 'common\models\PlaylistsHasMusics';
    public $modelMusic = 'common\models\Musics';
    public $userProvider = 'common\models\User';
    public $genresProvider = 'common\models\Genres';
    public $user = null;


    private function putProducerInMusic($model){
        foreach ($model->profiles as $profile) {
            $userAux = $this->userProvider::find()->where(['id' => $profile->id_user])->one();
            $this->user = $userAux;
            $model->producerOfThisSong = $userAux->username;
        }
        return $model;
    }

    private function putProducerInMusics($models){
        foreach ($models as $music) {
            foreach ($music->profiles as $profile) {
                $user = $this->userProvider::find()->where(['id' => $profile->id_user])->one();
                $music->producerOfThisSong = $user->username;
            }
        }
        return $models;
    }

    /*
    'GET musicswithproducer' => 'musicswithproducer',
    'GET {id}/title' => 'title', // 'x' é 'actionX'
    'GET {id}/launchdate' => 'launchdate', // 'x' é 'actionX'
    'GET {id}/lyrics' => 'lyrics', // 'x' é 'actionX'
    'GET {id}/pvp' => 'pvp', // 'x' é 'actionX'
    'GET {id}/musicpath' => 'musicpath', // 'x' é 'actionX'
    'GET {id}/genre' => 'genre', // 'x' é 'actionX'
    'GET {id}/producer' => 'producer', // 'xxxx' é 'actionXxxx'
    'GET count' => 'count',
    */

    public function actionNomeplaylist($id){
        $model = $this->modelClass::findOne($id);
        return $model->nome;
    }

    public function actionCreationdateplaylist($id){
        $model = $this->modelClass::findOne($id);
        return $model->creationdate;
    }
    public function actionMusicsplaylist($id){
        $model = $this->modelClass::findOne($id);

        //$models = $this->putProducerInMusics($models);
        return $model->musics;
    }

    public function actionMusic($id, $idmusic){
        $modelMusic = $this->modelMusic::findOne($idmusic);
        return $modelMusic;
    }
    public function actionTitlemusic($id, $idmusic){
        $model = $this->modelMusic::findOne($idmusic);
        return $model->title;
    }
    public function actionLaunchdatemusic($id, $idmusic){
        $model = $this->modelMusic::findOne($idmusic);
        return $model->launchdate;
    }
    public function actionLyricsmusic($id, $idmusic){
        $model = $this->modelMusic::findOne($idmusic);
        return $model->lyrics;
    }
    public function actionPvpmusic($id, $idmusic){
        $model = $this->modelMusic::findOne($idmusic);
        return $model->pvp;
    }
    public function actionMusicpathmusic($id, $idmusic){
        $model = $this->modelMusic::findOne($idmusic);
        return $model->musicpath;
    }
    public function actionGenremusic($id, $idmusic){
        $model = $this->modelMusic::findOne($idmusic);
        return $model->genres->nome;
    }
    public function actionProducermusic($id, $idmusic){
        $model = $this->modelMusic::findOne($idmusic);
        $model = $this->putProducerInMusic($model);
        return $model->producerOfThisSong;
    }
    public function actionMp3filemusic($id, $idmusic){
        $model = $this->modelMusic::findOne($idmusic);
        $model = $this->putProducerInMusic($model);
        return 'BeatBunny/advanced/frontend/web/uploads/'.$this->user->id.'/music_'.$model->id.'_'.$model->title.'.mp3';
    }

    public function actionNew(){
        $model = new $this->modelClass;
        $model->nome = Yii::$app->request->post('nome');
        $model->creationdate = Yii::$app->request->post('creationdate');
        $model->ispublica = Yii::$app->request->post('ispublica');
        
        if($model->save()){
            return ['SaveError' => 'TRUEEEE'];
        }
        else{
            return $model;
            return ['SaveError' => 'NOOOOOO'];
        }
    }

    public function actionPlaylistupdate($id){
        $nome = \Yii::$app->request->post('nome');
        $creationdate = date("Y-m-d");
        $model = new $this->modelClass;
        $rec = $model::find()->where(['id' => $id])->one();
        if(count($rec) > 0){
            $rec->nome = $nome;
            $ret = $rec->save();
            return ['SaveError' => $ret];
        }
        throw new \yii\web\NotFountHttpException("Não existe essa playlist");
    }

    public function actionPlaylistdelete($id){
        $model = new $this->modelClass;
        $ret = $model->deleteAll(['id' => $id]);
        if($ret){
            \Yii::$app->response->statusCode = 200;
            return ['code' => 'ok'];
        }
        \Yii::$app->response->statusCode = 404;
        return ['code' => 'error'];
    }

    public function actionPlaylistputsong(){
        $modelPHM = new $this->modelPHM;
        $model = new $this->modelClass;
        $modelmusica = new $this->modelMusic;
        $id =\Yii::$app->request->post('id');
        $idmusic =\Yii::$app->request->post('idmusic');        
        $musicaParaInserirNaPlaylist = $modelmusica::findOne($idmusic);
        $playlistParaInserir = $model::findOne($id);
        $modelPHM->playlists_id = $playlistParaInserir->id;
        $modelPHM->musics_id = $musicaParaInserirNaPlaylist->id;
        $ret = $modelPHM->save();
        return ['SaveError' => $ret];
    }



}
