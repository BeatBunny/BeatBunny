<?php

namespace backend\modules\v1\controllers;
use yii\rest\ActiveController;
use yii\web\Request;
use Yii;

class DefaultController extends ActiveController
{
	public $modelClass = 'common\models\User';
}
